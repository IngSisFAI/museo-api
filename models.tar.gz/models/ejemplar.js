'use strict'

const mongoose = require('mongoose')
const Schema  = mongoose.Schema

const AreaGeologicaSchema = Schema({
    formacion:String,
    grupo:String,
    subgrupo: String,
    edad:String,
    periodo: String,
    era:String    
})

const AreaHallazgoSchema = Schema({
    nombreArea:String,
    pais:String,
    ciudad:String,
    provincia:String
})

const Dupla = Schema({
    nombre:String,
    descripcion:String
})

const EjemplarOldSchema = Schema({
   tipoEjemplar:{type: String, enum:['Encontrado', 'No Encontrado']},
   taxonReino:String,
   taxonFilo:String,
   taxonClase:String,
   taxonOrden:String,
   taxonFamilia:String,
   taxonGenero:String,
   taxonEspecie:String,
   eraGeologica:AreaGeologicaSchema,
   ilustracionCompleta:String,
   descripcionIC:String,
   areaHallazgo:AreaHallazgoSchema,
   nroColeccion:String, 
   dimensionLargo:String,
   dimensionAlto:String,
   peso:String,
   alimentacion:String, 
   fechaIngresoColeccion:Date,
   ubicacionMuseo: String,
   fotosEjemplar:[Dupla],
   videosEjemplar:[String],
   fechaBaja: Date,
   motivoBaja:String,
   nombre:String,
   periodo:String,
   home:Boolean,
   descripcion1:String,
   descripcion1A:String,
   descripcion2:String,
   descripcion3:String,
   perteneceExca:String
})


const EjemplarSchema = Schema({
   sigla: String,
   tipoColeccion: String,
   tipoColeccionId: String,
   fechaIngreso: Date,
   fechaBaja: Date,
   motivoBaja: String, 
   taxonReino:String,
   taxonFilo:String,
   taxonClase:String,
   taxonOrden:String,
   taxonFamilia:String,
   taxonGenero:String,
   taxonEspecie:String,
   eraGeologica:AreaGeologicaSchema,
   fotosEjemplar:[Dupla],
   videosEjemplar:[String],
   ubicacionMuseo: String,
   preparador: String,
   tipoIntervencion: String, 
   autores: String,
   publicaciones: String, 
   archivosCurriculum: [String],
   materialIngresadoPor: String,
   observacionesAdic: String, 
   home:Boolean,
   areaHallazgo:AreaHallazgoSchema,
   perteneceExca:String

})

module.exports = mongoose.model('Ejemplar', EjemplarSchema)